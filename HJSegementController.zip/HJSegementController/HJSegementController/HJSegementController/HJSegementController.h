//
//  HJSegementController.h
//  HJSegementController
//
//  Created by ibamboo on 2017/3/27.
//  Copyright © 2017年 iBamboo. All rights reserved.
//

#import <UIKit/UIKit.h>
//高亮线的对其方式
typedef NS_ENUM(NSInteger, HJSegementStyle){
    HJSegementStyleDefault, //默认高亮线和title对其
    HJSegementStyleItem,    //和整个区域对其
    
};

@interface HJSegementController : UIViewController

@property (nonatomic, strong)UIColor *HJSegementTiltleColor;//选中时的子图颜色
@property (nonatomic, strong)NSArray *viewControllers;//容器要控制的视图
//segmentView
@property (nonatomic, strong) UIScrollView *segementView;
@property (nonatomic, assign) HJSegementStyle lineStyle;

+ (instancetype)segementControllerWithFrame:(CGRect)frame titles:(NSArray <NSString *>*)titles;
- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles;
- (void)setSegementViewControllers:(NSArray <UIViewController *>*)viewControllers;
/**
 返回当前被选中的item的索引
 */
- (NSInteger)selectedAtIndex;
//获取到选中的item索引
- (void)selectedAtIndex:(void(^)(NSInteger index))indexBlock;
/**
 手动指定选中的item
 */
- (void)setSelectedItemAtIndex:(NSInteger)index;
@end
