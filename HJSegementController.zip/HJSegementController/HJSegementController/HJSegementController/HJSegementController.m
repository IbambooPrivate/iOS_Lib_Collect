//
//  HJSegementController.m
//  HJSegementController
//
//  Created by ibamboo on 2017/3/27.
//  Copyright © 2017年 iBamboo. All rights reserved.
//

#import "HJSegementController.h"

@interface HJSegementController ()<UIScrollViewDelegate>

typedef void(^indexBlock)(NSInteger index);

@property (nonatomic, strong) UIScrollView *containerView;

@property (nonatomic, strong) UIButton *selectedButton; //当前被选中的按钮
@property (nonatomic, assign) CGSize size;
@property (nonatomic, strong) NSArray *titles;
@property (nonatomic, strong) UIView *lineView;     // 高亮线
@property (nonatomic, assign) CGFloat lineHeight;   // 高亮线高度
@property (nonatomic, assign) NSTimeInterval duration;  //滑动时间
@property (nonatomic, assign) CGFloat segementHeight;   //segementView的高度
@property (nonatomic, assign) CGFloat buttonSpace;      //按钮title到边的间距
@property (nonatomic, assign) CGFloat minItemSpace;     //最小Item之间的间距
@property (nonatomic, strong) UIFont *font;  //title的字体大小
@property (nonatomic, strong) UIColor *normalColor;     // 标题未被选中时的颜色
@property (nonatomic, copy)   indexBlock resultBlock;
@property (nonatomic, strong) NSMutableArray *widthArr; //存放按钮的宽度

@end

@implementation HJSegementController

- (instancetype)initWithFrame:(CGRect)frame titles:(NSArray *)titles {
    if (self = [super init]) {
        _titles = titles;
        _size = frame.size;
        self.view.frame = frame;
        [self segementBasicSetting];
        [self segementPageSetting];
        [self containerViewSetting];
    }
    return self;
}

+ (instancetype)segementControllerWithFrame:(CGRect)frame titles:(NSArray<NSString *> *)titles {
    return [[self alloc] initWithFrame:frame titles:titles];
}

- (void)segementBasicSetting {
    self.view.backgroundColor = [UIColor clearColor];
    _widthArr = [NSMutableArray array];
    _segementHeight = 44.;
    _minItemSpace = 20.;
    _HJSegementTiltleColor = [UIColor colorWithRed:133/255.0 green:159/255.0 blue:255/255.0 alpha:1];
    _normalColor = [UIColor whiteColor];
    _font = [UIFont systemFontOfSize:12];
    _buttonSpace = [self calculateSpace];
    _lineHeight = 2.;
    _duration = .3;
}

- (void)segementPageSetting {
    _segementView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, _size.width, _segementHeight)];
    _segementView.backgroundColor =  [UIColor colorWithRed:24/255.0 green:22/255.0 blue:51/255.0 alpha:1];
    _segementView.showsHorizontalScrollIndicator = NO;
    _segementView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_segementView];
    
    _lineView = [[UIView alloc] init];
    _lineView.backgroundColor = _HJSegementTiltleColor;
    
    CGFloat item_x = 0;
    for (int i = 0; i < _titles.count; i++) {
        NSString *title = _titles[i];
        CGSize titleSize = [title sizeWithAttributes:@{NSFontAttributeName: _font}];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.titleLabel.font = _font;
        button.frame = CGRectMake(item_x, 0, _buttonSpace * 2 + titleSize.width, _segementHeight);
        [button setTag:i];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:_normalColor forState:UIControlStateNormal];
        [button setTitleColor:_HJSegementTiltleColor forState:UIControlStateSelected];
        [button addTarget:self action:@selector(didClickButton:) forControlEvents:UIControlEventTouchUpInside];
        [_segementView addSubview:button];
        
        [_widthArr addObject:[NSNumber numberWithDouble:CGRectGetWidth(button.frame)]];
        item_x += _buttonSpace * 2 + titleSize.width;
        
        if (i == 0) {
            button.selected = YES;
            _selectedButton = button;
            
            // 添加高亮线
            _lineView.frame = CGRectMake(_buttonSpace, _segementHeight - _lineHeight, titleSize.width, _lineHeight);
            [_segementView addSubview:_lineView];
        }
    }
    
    self.segementView.contentSize = CGSizeMake(item_x, _segementHeight);
}

- (void)containerViewSetting {
    _containerView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, _segementHeight, _size.width, _size.height - _segementHeight)];
   _containerView.backgroundColor =  [UIColor colorWithRed:24/255.0 green:22/255.0 blue:51/255.0 alpha:1];
    _containerView.showsVerticalScrollIndicator = NO;
    _containerView.showsHorizontalScrollIndicator = NO;
    _containerView.delegate = self;
    _containerView.pagingEnabled = YES;
    _containerView.bounces = NO;
    [self.view addSubview:_containerView];
}

- (CGFloat)calculateSpace {
    CGFloat space = 0.;
    CGFloat totalWidth = 0.;
    
    for (NSString *title in _titles) {
        CGSize titleSize = [title sizeWithAttributes:@{NSFontAttributeName : _font}];
        totalWidth += titleSize.width;
    }
    
    space = (_size.width - totalWidth) / _titles.count / 2;
    if (space > _minItemSpace / 2) {
        return space;
    } else {
        return _minItemSpace / 2;
    }
}

- (void)selectedAtIndex:(void (^)(NSInteger))indexBlock {
    if (indexBlock) {
        _resultBlock = indexBlock;
        _resultBlock([self selectedAtIndex]);
    }
}

#pragma mark -- 按钮方法

- (void)didClickButton:(UIButton *)button {
    if (button != _selectedButton) {
        button.selected = YES;
        _selectedButton.selected = !_selectedButton.selected;
        _selectedButton = button;
        
        [self scrollIndicateView];
        [self scrollSegementView];
    }
    
    if (_resultBlock) {
        _resultBlock(_selectedButton.tag);
    }
}

/**
 根据选中的按钮高亮线
 */
- (void)scrollIndicateView {
    NSInteger index = [self selectedAtIndex];
    CGSize titleSize = [_selectedButton.titleLabel.text sizeWithAttributes:@{NSFontAttributeName : _font}];
    [UIView animateWithDuration:_duration delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        if (_lineStyle == HJSegementStyleDefault) {
            _lineView.frame = CGRectMake(CGRectGetMinX(_selectedButton.frame) + _buttonSpace, CGRectGetMinY(_lineView.frame), titleSize.width, _lineHeight);
        } else {
            _lineView.frame = CGRectMake(CGRectGetMinX(_selectedButton.frame), CGRectGetMinY(_lineView.frame), [self widthAtIndex:index], _lineHeight);
        }
        
        [_containerView setContentOffset:CGPointMake(index * _size.width, 0)];
    } completion:^(BOOL finished) {
        
    }];
}

/**
 根据选中调整segementView的offset
 */
- (void)scrollSegementView {
    CGFloat selectedWidth = _selectedButton.frame.size.width;
    CGFloat offsetX = (_size.width - selectedWidth) / 2;
    
    if (_selectedButton.frame.origin.x <= _size.width / 2) {
        [_segementView setContentOffset:CGPointMake(0, 0) animated:YES];
    } else if (CGRectGetMaxX(_selectedButton.frame) >= (_segementView.contentSize.width - _size.width / 2)) {
        [_segementView setContentOffset:CGPointMake(_segementView.contentSize.width - _size.width, 0) animated:YES];
    } else {
        [_segementView setContentOffset:CGPointMake(CGRectGetMinX(_selectedButton.frame) - offsetX, 0) animated:YES];
    }
}

#pragma mark -- index

- (NSInteger)selectedAtIndex {
    return _selectedButton.tag;
}

- (void)setSelectedItemAtIndex:(NSInteger)index {
    for (UIView *view in _segementView.subviews) {
        if ([view isKindOfClass:[UIButton class]] && view.tag == index) {
            UIButton *button = (UIButton *)view;
            [self didClickButton:button];
        }
    }
}

- (CGFloat)widthAtIndex:(NSInteger)index {
    if (index < 0 || index > _titles.count - 1) {
        return .0;
    }
    return [[_widthArr objectAtIndex:index] doubleValue];
}

#pragma mark -- scrollView delegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSInteger index = round(scrollView.contentOffset.x / _size.width);
    [self setSelectedItemAtIndex:index];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    CGFloat offsetX = scrollView.contentOffset.x;
    
    NSInteger currentIndex = [self selectedAtIndex];
    
    // 当当前的偏移量大于被选中index的偏移量的时候，就是在右侧
    CGFloat offset; // 在同一侧的偏移量
    NSInteger buttonIndex = currentIndex;
    if (offsetX >= [self selectedAtIndex] * _size.width) {
        offset = offsetX - [self selectedAtIndex] * _size.width;
        buttonIndex += 1;
    } else {
        offset = [self selectedAtIndex] * _size.width - offsetX;
        buttonIndex -= 1;
        currentIndex -= 1;
    }
    
    CGFloat originMovedX = _lineStyle == HJSegementStyleDefault? (CGRectGetMinX(_selectedButton.frame) + _buttonSpace) : CGRectGetMinX(_selectedButton.frame);
    CGFloat targetMovedWidth = [self widthAtIndex:currentIndex];//需要移动的距离
    
    CGFloat targetButtonWidth = _lineStyle == HJSegementStyleDefault? ([self widthAtIndex:buttonIndex] - 2 * _buttonSpace) : [self widthAtIndex:buttonIndex]; // 这个会影响width
    CGFloat originButtonWidth = _lineStyle == HJSegementStyleDefault? ([self widthAtIndex:[self selectedAtIndex]] - 2 * _buttonSpace) : [self widthAtIndex:[self selectedAtIndex]];
    
    
    CGFloat moved; // 移动的距离
    moved = offsetX - [self selectedAtIndex] * _size.width;
    _lineView.frame = CGRectMake(originMovedX + targetMovedWidth / _size.width * moved, _lineView.frame.origin.y,  originButtonWidth + (targetButtonWidth - originButtonWidth) / _size.width * offset, _lineView.frame.size.height);
}

#pragma mark -- set

- (void)setSegementTintColor:(UIColor *)segementTintColor {
    segementTintColor = segementTintColor;
    _lineView.backgroundColor = segementTintColor;
    for (UIView *view in _segementView.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            [button setTitleColor:segementTintColor forState:UIControlStateSelected];
        }
    }
}

- (void)setSegementViewControllers:(NSArray *)viewControllers {
    [self setViewControllers:viewControllers];
}

- (void)setViewControllers:(NSArray *)viewControllers {
    _viewControllers = viewControllers;
    _containerView.contentSize = CGSizeMake(viewControllers.count * _size.width, _size.height - _segementHeight);
    for (int i = 0; i < viewControllers.count; i++) {
        UIViewController *viewController = viewControllers[i];
        viewController.view.frame = CGRectOffset(_containerView.bounds, i * _size.width, 0);
        [_containerView addSubview:viewController.view];
        [self addChildViewController:viewController];
    }
}

- (void)setStyle:(HJSegementStyle)style {
    _lineStyle = style;
    
    if (style == HJSegementStyleDefault) {
        
    } else {
        _lineView.frame = CGRectMake(_selectedButton.frame.origin.x, _segementHeight - _lineHeight, [self widthAtIndex:0], _lineHeight);
    }
}

@end
