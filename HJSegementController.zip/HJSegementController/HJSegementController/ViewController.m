//
//  ViewController.m
//  HJSegementController
//
//  Created by ibamboo on 2017/3/27.
//  Copyright © 2017年 iBamboo. All rights reserved.
//

#import "ViewController.h"
#import "HJSegementController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    // Do any additional setup after loading the view, typically from a nib.
     UIViewController  *v1 = [UIViewController new];
    v1.view.backgroundColor = [UIColor redColor];
    
    UIViewController *v2 = [UIViewController new];
    v2.view.backgroundColor = [UIColor yellowColor];

    
    UIViewController *v3 = [[UIViewController alloc]init];
    v3.view.backgroundColor = [UIColor colorWithRed:24/255.0 green:22/255.0 blue:51/255.0 alpha:1];

    HJSegementController *HJVC = [HJSegementController  segementControllerWithFrame:CGRectMake(0,20, self.view.bounds.size.width, self.view.bounds.size.height) titles:@[@"2222",@"2222",@"2222"]];
    HJVC.viewControllers = @[v1,v2,v3];
    [self.view addSubview:HJVC.view];
    [self addChildViewController:HJVC];


    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
