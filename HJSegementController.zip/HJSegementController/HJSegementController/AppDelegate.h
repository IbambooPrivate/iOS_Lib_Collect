//
//  AppDelegate.h
//  HJSegementController
//
//  Created by ibamboo on 2017/3/27.
//  Copyright © 2017年 iBamboo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

