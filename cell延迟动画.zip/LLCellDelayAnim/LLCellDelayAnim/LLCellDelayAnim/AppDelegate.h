//
//  AppDelegate.h
//  LLCellDelayAnim
//
//  Created by liushaohua on 2017/1/20.
//  Copyright © 2017年 liushaohua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

