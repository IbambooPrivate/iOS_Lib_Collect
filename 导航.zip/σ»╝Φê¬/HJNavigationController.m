//
//  HJNavigationController.m
//  自定义封装导航栏
//
//  Created by 四川艺匠天诚科技有限公司 on 16/7/4.
//  Copyright © 2016年 四川艺匠天诚科技有限公司. All rights reserved.
//

/*
 全是说明
 iOS 7中在传统的左上角返回键之外，提供了右滑返回上一级界面的手势。支持此手势的是UINavigationController中新增的属性
 
 interactivePopGestureRecognizer，即右滑返回只支持以UINavigationController为容器的ViewController间切换，要想在自定义容器中使用，需要一些额外的工作。
 
 基本地，控制ViewController是否启用右滑返回，只需要这样：
 
 1 self.navigationController.interactivePopGestureRecognizer.enabled = YES;
 默认情况下enabled为YES。
 
 
 
 */
#import "HJNavigationController.h"
//UIGestureRecognizerDelegate 这个协议用来调用手势，侧滑返回
#define COLOR_ALPHA(r,g,b,a)  [UIColor colorWithRed:(r)/255.f green:(g)/255.f blue:(b)/255.f alpha:(a)]
@interface HJNavigationController ()<UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIColor *color;
@end

@implementation HJNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置NavigationBar
    [self setupNavigationBar];
    //设置手势代理
    self.interactivePopGestureRecognizer.delegate = self;
    //导航栏整体颜色的色调
    _color = [UIColor redColor];
}


//设置导航栏主题
- (void)setupNavigationBar{
    UINavigationBar *appearance = [UINavigationBar appearance];
    //统一设置导航栏颜色，如果单个见面需要设置，可以在ViewWillAppear方法中设置,在viewWillDisappear设置回统一格式
    //（色号16进制）
    [appearance setBarTintColor:[UIColor whiteColor]];
    //导航栏title格式
    NSMutableDictionary *textAttribute = [NSMutableDictionary dictionary];
    textAttribute[NSForegroundColorAttributeName] = [UIColor whiteColor];
    textAttribute[NSFontAttributeName] = [UIFont systemFontOfSize:15];
    [appearance setTitleTextAttributes:textAttribute];
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if (self.viewControllers.count > 0) {
        viewController.hidesBottomBarWhenPushed = YES;
        UIButton *backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 22, 22)];
        [backButton setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateNormal];
        [backButton setImage:[UIImage imageNamed:@"back.png"] forState:UIControlStateHighlighted];
        [backButton setImageEdgeInsets:UIEdgeInsetsMake(0, -10, 0, 0)];
        [backButton addTarget:self action:@selector(popView) forControlEvents:UIControlEventTouchUpInside];
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:backButton];
    }
    [super pushViewController:viewController animated:animated];
}
- (void)popToViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [super popToRootViewControllerAnimated:YES];
}
- (void)popView
{
    [self popViewControllerAnimated:YES];
}

//手势代理
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (self.navigationController.viewControllers.count == 1) {
        return NO;
    }else{
        return YES;
    }
    
}
- (BOOL)shouldAutorotate {
    return YES;
}
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
    return UIInterfaceOrientationPortrait;
}

#if !ShowBug
- (UIViewController *)childViewControllerForStatusBarStyle{
    return self.visibleViewController;
}
#endif
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
