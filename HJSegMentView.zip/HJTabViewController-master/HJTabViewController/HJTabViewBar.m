//
//  HJTabViewBar.m
//  HJTabViewControllerDemo
//
//  Created by haijiao on 2017/3/15.
//  Copyright © 2017年 olinone. All rights reserved.
//

#import "HJTabViewBar.h"

@implementation HJTabViewBar

- (void)reloadTabBar {
    NSAssert(NO, @"Subclass must be implementation this method");
}

@end
