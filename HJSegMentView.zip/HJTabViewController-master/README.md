# HJTabViewController

![](https://img.shields.io/badge/build-passing-brightgreen.svg)
![](https://img.shields.io/badge/pod-v0.4.1-blue.svg)
![](https://img.shields.io/badge/language-objc-5787e5.svg)
![](https://img.shields.io/badge/license-MIT-brightgreen.svg)  

![Smaller icon](http://7pum7o.com1.z0.glb.clouddn.com/HJTabView0.gif)

## Installation with CocoaPods

[CocoaPods](http://cocoapods.org/) is a dependency manager for Objective-C, which automates and simplifies the process of using 3rd-party libraries in your projects. See the [Get Started](http://cocoapods.org/#get_started) section for more details.

## Podfile

```
pod 'HJTabViewController',     :git => 'https://github.com/panghaijiao/HJTabViewController.git'
```


## License

HJTabViewController is released under the MIT license. See LICENSE for details.
