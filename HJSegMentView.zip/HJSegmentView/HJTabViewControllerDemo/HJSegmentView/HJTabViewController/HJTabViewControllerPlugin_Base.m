//
//  HJTabViewControllerPlugin_Base.m
//  HJTabViewControllerDemo
//
//  Created by haijiao on 2017/3/14.
//  Copyright © 2017年 olinone. All rights reserved.
//

#import "HJTabViewControllerPlugin_Base.h"

@implementation HJTabViewControllerPlugin_Base

- (void)initPlugin {
}

- (void)loadPlugin {
}

- (void)removePlugin {
}

#pragma mark -

- (void)scrollViewVerticalScroll:(CGFloat)contentPercentY {
}

- (void)scrollViewHorizontalScroll:(CGFloat)contentOffsetX {
}

- (void)scrollViewWillScrollFromIndex:(NSInteger)index {
}

- (void)scrollViewDidScrollToIndex:(NSInteger)index {
}

@end
